﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class CustomBO
    {
        public int customMsgNumber { get; set; }
        public string customMsg { get; set; }
    }   
}
