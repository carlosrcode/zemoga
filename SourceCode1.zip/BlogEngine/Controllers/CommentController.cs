﻿using BusinessLogic;
using Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BlogEngine.Controllers
{
    public class CommentController : Controller
    {
        //CR 01/03/2022 In this controller takes place the management of the comments.

        public ActionResult Index(int id)
        {
            ViewBag.PostId = id;
            CommentBL objCommentBL = new CommentBL();
            var comenntList = objCommentBL.List(id);
            return View(comenntList);
        }

        public ActionResult AddComment(int postId)
        {
            Comment objComment = new Comment();

            if (User.Identity.IsAuthenticated)
                objComment.Username = User.Identity.Name;
            objComment.PostId = postId;

            return View(objComment);
        }

        [HttpPost]
        public ActionResult AddComment(Comment objComment)
        {
            CommentBL objCommentBL = new CommentBL();
            
            objComment.CreatedDate = System.DateTime.Now;
            CustomBO objRes = objCommentBL.AddComment(objComment);
            TempData["msg"] = objRes.customMsg;
            return RedirectToAction("Index/"+objComment.PostId);
        }

    }
}