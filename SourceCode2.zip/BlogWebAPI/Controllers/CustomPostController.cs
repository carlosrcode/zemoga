﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using BlogWebAPI.Models;

namespace BlogWebAPI.Controllers
{
    public class CustomPostController : ApiController
    {
        private BlogEngineContext db = new BlogEngineContext();

        //CR 01/03/2022 Retrieve ALL posts

        // GET: api/CustomPost/GetAllPosts
        public IQueryable<vw_Posts> GetAllPosts()
        {
            return db.vw_Posts;
        }


        //CR 01/03/2022 Retrieve post with an specific Status (D/S/A/R)

        // GET: api/CustomPost/GetPosts?status=D
        public async Task<IHttpActionResult> GetPosts(string status)
        {
            var vw_Posts = await (db.vw_Posts.Where(p => p.Status == status).Select(
                c => new CustomPost { PostId = c.PostId, Author = c.FullName, SubmittedDate = c.SubmittedDate ?? DateTime.MinValue})).ToListAsync();
            if (vw_Posts == null)
            {
                NotFound();
            }

            return Ok(vw_Posts);
        }


        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

    }
}