﻿using BlogWebAPI;
using BusinessLogic;
using Entities;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace BlogEngine.Controllers
{

    public class HomeController : Controller
    {
        //CR 01/03/2022 In this controller takes place the management of the post, taking in account if the user is authenticated or not. As well as the role.

        BlogWebAPI blogAPI = new BlogWebAPI();

        public ActionResult Index()
        {

            PostBL objPostBL = new PostBL();

            string usernameReq = "";
            string status = "A";
            string role = "";
                       
            List<Entities.vw_Posts> arrPost = objPostBL.ListPost(usernameReq, role, status);
            return View(arrPost);
        }

        public ActionResult Wall()
        {
            //CR 01/03/2022 Writers are redirected to its management panel, as well as, editors.
            //              Non-authenticated users are redirected to the default panel, where they can add comments for approved posts.

            string msg = Convert.ToString(TempData["msg"]);
            ViewBag.Message = msg;

            if (User.Identity.IsAuthenticated)
            {
                if (User.IsInRole(CustomUserRole.Writer))
                    return RedirectToAction("PostWriter");

                if (User.IsInRole(CustomUserRole.Editor))
                    return RedirectToAction("PostEditor");
            }
            return RedirectToAction("Index");
        }

        public async Task<ActionResult> WallByWebService()
        {
            //CR 01/03/2022 Application consumes web service to retrieve all the Submitted post for Editor (Wall By WS)

            string msg = Convert.ToString(TempData["msg"]);
            ViewBag.Message = msg;

            if (User.Identity.IsAuthenticated)
            {
                if (User.IsInRole(CustomUserRole.Editor))
                {
                    List<Entities.CustomPost> post = new List<Entities.CustomPost>();

                    HttpClient client = blogAPI.Initialize();
                    HttpResponseMessage res = await client.GetAsync("api/CustomPost/GetPosts?status=S");
                    if (res.IsSuccessStatusCode)
                    {
                        var result = res.Content.ReadAsStringAsync().Result;
                        post = JsonConvert.DeserializeObject<List<Entities.CustomPost>>(result);
                    }
                    
                    return View(post);
                }
            }
            return RedirectToAction("Index");
        }

        [HttpPost]
        public async Task<ActionResult> WallByWebService(string status)
        {
            //CR 01/03/2022 Application consumes web service to retrieve all Posts (based on the status) for Editor
            //              At this moment, it is not implemented from UI side.

            string msg = Convert.ToString(TempData["msg"]);
            ViewBag.Message = msg;

            if (User.Identity.IsAuthenticated)
            {
                if (User.IsInRole(CustomUserRole.Editor))
                {
                    List<Entities.CustomPost> post = new List<Entities.CustomPost>();

                    HttpClient client = blogAPI.Initialize();
                    HttpResponseMessage res = await client.GetAsync("api/CustomPost/GetPosts?status=" + status);
                    if (res.IsSuccessStatusCode)
                    {
                        var result = res.Content.ReadAsStringAsync().Result;
                        post = JsonConvert.DeserializeObject<List<Entities.CustomPost>>(result);
                    }

                    return View(post);
                }
            }
            return RedirectToAction("Index");
        }

        public ActionResult PostWriter()
        {
            //CR 01/03/2022 Post Management View for Writers. They have access only to theirs posts.

            PostBL objPostBL = new PostBL();
            string usernameReq = "";
            string status = "";
            string role = "";
            string msg = Convert.ToString(TempData["msg"]);
            ViewBag.Message = msg;

            if (User.Identity.IsAuthenticated)
            {
                if (User.IsInRole(CustomUserRole.Writer))
                {
                    role = CustomUserRole.Writer;
                    usernameReq = User.Identity.Name;
                    status = "*";
                    List<Entities.vw_Posts> arrPost = objPostBL.ListPost(usernameReq, role, status);
                    return View(arrPost);
                }
            }
            return RedirectToAction("Index");
        }

        public ActionResult PostEditor()
        {
            //CR 01/03/2022 Post Management View for Editors.

            PostBL objPostBL = new PostBL();
            string usernameReq = "";
            string status = "";
            string role = "";
            string msg = Convert.ToString(TempData["msg"]);
            ViewBag.Message = msg;

            if (User.Identity.IsAuthenticated)
            {
                if (User.IsInRole(CustomUserRole.Editor))
                {
                    role = CustomUserRole.Editor;
                    usernameReq = User.Identity.Name;
                    status = "*";
                    List<Entities.vw_Posts> arrPost = objPostBL.ListPost(usernameReq, role, status);
                    return View(arrPost);
                }
            }
            return RedirectToAction("Index");
        }

        public ActionResult PostWriterCreatePost()
        {
            if (User.Identity.IsAuthenticated)
            {
                if (User.IsInRole(CustomUserRole.Writer))
                {
                    Entities.Post objPost = new Entities.Post();
                    objPost.Username = User.Identity.Name;
                    return View(objPost);
                }
            }
            return RedirectToAction("Index");
        }



        [HttpPost]
        public ActionResult PostWriterCreatePost(Entities.Post objPost)
        {
            PostBL objPostBL = new PostBL();

            if (User.Identity.IsAuthenticated)
            {
                if (User.IsInRole(CustomUserRole.Writer))
                {
                    objPost.CreatedDate = System.DateTime.Now;
                    CustomBO objRes = objPostBL.AddPost(objPost);
                    TempData["msg"] = objRes.customMsg;
                }
            }
            return RedirectToAction("Wall");
        }


        public ActionResult PostWriterEditPost(int id)
        {
            if (User.Identity.IsAuthenticated)
            {
                if (User.IsInRole(CustomUserRole.Writer))
                {
                    PostBL objPostBL = new PostBL();
                    Entities.Post objPost = objPostBL.GetPost(id);
                    return View(objPost);
                }
            }
            return RedirectToAction("Index");
        }

        [HttpPost]
        public ActionResult PostWriterEditPost(Entities.Post objPost)
        {
            PostBL objPostBL = new PostBL();

            if (User.Identity.IsAuthenticated)
            {
                if (User.IsInRole(CustomUserRole.Writer))
                {
                    objPost.ModifiedDate = System.DateTime.Now;
                    CustomBO objRes = objPostBL.SavePost(objPost);
                    TempData["msg"] = objRes.customMsg;
                }
            }
            return RedirectToAction("Wall");
        }

        public ActionResult UpdateStatus(int id, string status)
        {
            //CR 01/03/2022     All changes of the post status are executed in this section  

            if (User.Identity.IsAuthenticated)
            {
                if (User.IsInRole(CustomUserRole.Writer))
                {
                    PostBL objPostBL = new PostBL();
                    Entities.Post objPost = objPostBL.GetPost(id);
                    if (objPost.Username == User.Identity.Name && (objPost.Status == CustomPostStatus.Draft || objPost.Status == CustomPostStatus.Rejected))
                    {
                        if (status == CustomPostStatus.Submitted)
                            objPost.SubmittedDate = System.DateTime.Now;
                        objPost.Status = status;
                        CustomBO objRes = objPostBL.SavePost(objPost);
                        TempData["msg"] = objRes.customMsg;
                    }
                }

                if (User.IsInRole(CustomUserRole.Editor))
                {
                    PostBL objPostBL = new PostBL();
                    Entities.Post objPost = objPostBL.GetPost(id);
                    if (objPost.Status == CustomPostStatus.Submitted)
                    {
                        if (status == CustomPostStatus.Approved)
                            objPost.ApprovedDate = System.DateTime.Now;

                        objPost.Status = status;
                        CustomBO objRes = objPostBL.SavePost(objPost);
                        TempData["msg"] = objRes.customMsg;
                    }
                }
            }
            return RedirectToAction("Wall");
        }

        public ActionResult DeletePost(int? id)
        {
            PostBL objPostBL = new PostBL();

            if (id == null)
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);

            Entities.Post objPost = objPostBL.GetPost(id.Value);

            if (User.Identity.IsAuthenticated)
            {
                if (User.IsInRole(CustomUserRole.Editor))
                {
                    return View(objPost);
                }
            }
            return RedirectToAction("Index");
        }

        [HttpPost]
        public ActionResult DeletePost(int id)
        {
            PostBL objPostBL = new PostBL();
            CommentBL objCommentBL = new CommentBL();
            if (User.Identity.IsAuthenticated)
            {
                if (User.IsInRole(CustomUserRole.Editor))
                {
                    CustomBO objResC = objCommentBL.DeleteComment(id);
                    CustomBO objResP = objPostBL.DeletePost(id);
                    TempData["msg"] = "Deleting commments:" + objResC.customMsg + " Deleting Post: " + objResP.customMsg;
                }
            }
            return RedirectToAction("Wall");
        }

    }
}