﻿using Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess
{
    public class CommentDL
    {
        //CR 01/03/2022 Data layer

        BlogEngineContext db;

        public CommentDL()
        {
            db = new BlogEngineContext();
        }

        public CustomBO AddComment(Comment objComment)
        {
            CustomBO oCustomBO = new CustomBO();
            Comment oComment = new Comment()
            {
                Description = objComment.Description,
                PostId = objComment.PostId,
                Username = objComment.Username,
                CreatedDate = objComment.CreatedDate
            };
            db.Comment.Add(oComment);
            int returnValue = db.SaveChanges();
            if (returnValue > 0)
            {
                oCustomBO.customMsgNumber = returnValue;
                oCustomBO.customMsg = "Completed successfully.";
            }
            else
            {
                oCustomBO.customMsgNumber = returnValue;
                oCustomBO.customMsg = "Failed.";
            }
            return oCustomBO;
        }

        public List<Comment> List(int postId)
        {
            List<Comment> commentList = null;
            commentList = db.Comment.Where(c => c.PostId == postId).ToList();
            return commentList;

        }
        public CustomBO DeleteComment(int postId)
        {
            CustomBO oCustomBO = new CustomBO();
            int returnValue = -1;
            try
            {
                foreach (var item in db.Comment.Where(c => c.PostId == postId))
                {
                    db.Comment.Remove(item);
                }
                returnValue = db.SaveChanges();
            }
            finally
            {
                if (returnValue > 0)
                {
                    oCustomBO.customMsgNumber = returnValue;
                    oCustomBO.customMsg = "Completed successfully.";
                }
                else
                {
                    if (returnValue == 0)
                    {
                        oCustomBO.customMsgNumber = returnValue;
                        oCustomBO.customMsg = "No comments found.";
                    }
                    else
                    {
                        oCustomBO.customMsgNumber = returnValue;
                        oCustomBO.customMsg = "Failed.";
                    }
                }
            }
            return oCustomBO;
        }

    }
}
