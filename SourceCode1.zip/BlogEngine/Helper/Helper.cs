﻿using System;
using System.Net.Http;

namespace BlogEngine
{
    //CR 01/03/2022 Helper classes 

    public static class CustomUserRole
    {
        public const string
            Writer = "Writer",
            Editor = "Editor";
    }

    public static class CustomPostStatus
    {
        public const string
        Draft = "D",
        Submitted = "S",
        Approved = "A",
        Rejected = "R",
        Any = "*";
    }

    public class BlogWebAPI
    {
        public HttpClient Initialize()
        {
            var client = new HttpClient();
            client.BaseAddress = new Uri("https://blogwebapi20220301.azurewebsites.net/");
            return client;
        }
    }
}