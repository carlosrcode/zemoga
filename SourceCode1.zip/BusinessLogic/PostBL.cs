﻿using DataAccess;
using Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic
{
    //CR 01/03/2022 Bussiness layer

    public class PostBL
    {
        public Post GetPost(int postId)
        {
            return new PostDL().GetPost(postId);
        }

        public CustomBO AddPost(Post objPost)
        {
            return new PostDL().AddPost(objPost);
        }

        public CustomBO SavePost(Post objPost)
        {
            return new PostDL().SavePost(objPost);
        }

        public CustomBO DeletePost(int id)
        {
            return new PostDL().DeletePost(id);
        }

        public List<vw_Posts> ListPost(string usernameReq, string role, string status)
        {
            return new PostDL().ListPost(usernameReq, role, status);
        }


    }
}
