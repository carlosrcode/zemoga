﻿namespace DataAccess
{
    public static class CustomUserRole
    {
        public const string
            Writer = "Writer",
            Editor = "Editor";
    }
    public static class CustomPostStatus
    {
        public const string
        Draft = "D",
        Submitted = "S",
        Approved = "A",
        Rejected = "R",
        Any = "*";
    }
}