﻿using DataAccess;
using Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic
{
    //CR 01/03/2022 Bussiness layer

    public class CommentBL
    {
        public CustomBO AddComment(Comment objComment)
        {
            return new CommentDL().AddComment(objComment);
        }

        public CustomBO DeleteComment(int commmentId)
        {
            return new CommentDL().DeleteComment(commmentId);
        }

        public List<Comment> List(int postId)
        {
            return new CommentDL().List(postId);
        }
    }
}
