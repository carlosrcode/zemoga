﻿using Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess
{

    public class PostDL
    {
        //CR 01/03/2022 Data layer

        BlogEngineContext db;
        public PostDL()
        {
            db = new BlogEngineContext();
        }

        public Post GetPost(int postId)
        {
            return db.Post.Where(p => p.PostId == postId).FirstOrDefault();
        }

        public CustomBO AddPost(Post objPost)
        {
            CustomBO oCustomBO = new CustomBO();

            int returnValue = -1;
            try
            {
                Post oPost = new Post()
                {
                    Title = objPost.Title,
                    Intro = objPost.Intro,
                    Body = objPost.Body,
                    Status = "D",
                    CreatedDate = objPost.CreatedDate,
                    Username = objPost.Username
                };
                db.Post.Add(oPost);
                returnValue = db.SaveChanges();
            }
            finally
            { 
                if (returnValue > 0)
                {
                    oCustomBO.customMsgNumber = returnValue;
                    oCustomBO.customMsg = "Completed successfully.";
                }
                else
                {
                    oCustomBO.customMsgNumber = returnValue;
                    oCustomBO.customMsg = "Failed.";
                }
            }
            return oCustomBO;
        }

        public CustomBO SavePost(Post objPost)
        {
            CustomBO oCustomBO = new CustomBO();

            int returnValue = -1;
            try
            {
                Post oPost = db.Post.Where(p => p.PostId == objPost.PostId).FirstOrDefault();
                oPost.Title = objPost.Title;
                oPost.Intro = objPost.Intro;
                oPost.Body = objPost.Body;
                oPost.Status = objPost.Status;
                oPost.SubmittedDate = objPost.SubmittedDate;
                oPost.ApprovedDate = objPost.ApprovedDate;
                oPost.ModifiedDate = objPost.ModifiedDate;

                returnValue = db.SaveChanges();
            }
            finally
            {
                if (returnValue > 0)
                {
                    oCustomBO.customMsgNumber = returnValue;
                    oCustomBO.customMsg = "Completed successfully.";
                }
                else
                {
                    oCustomBO.customMsgNumber = returnValue;
                    oCustomBO.customMsg = "Failed.";
                }
            }
            return oCustomBO;
        }

        public CustomBO DeletePost(int id)
        {
            CustomBO oCustomBO = new CustomBO();
            int returnValue = -1;
            try {
                Post oPost = db.Post.Where(p => p.PostId == id).FirstOrDefault();
                db.Post.Remove(oPost);
                returnValue = db.SaveChanges();
            }
            finally
            {
                if (returnValue > 0)
                {
                    oCustomBO.customMsgNumber = returnValue;
                    oCustomBO.customMsg = "Completed successfully.";
                }
                else
                {
                    if (returnValue == 0)
                    {
                        oCustomBO.customMsgNumber = returnValue;
                        oCustomBO.customMsg = "No comments found.";
                    }
                    else
                    {
                        oCustomBO.customMsgNumber = returnValue;
                        oCustomBO.customMsg = "Failed.";
                    }
                }
            }
            return oCustomBO;
        }

        public List<vw_Posts> ListPost(string usernameReq, string role, string status)
        {
            List<vw_Posts> postList = null;

            //CR 27/02/2022 When retrieving Posts should users should be distingued by Autenticated user or Non-Authenticated users
            //              Authenticated users must have a username and a role.
            if (usernameReq != "")
            {
                //CR 27/02/2022 Editors can request any post based on the post status
                if (role == CustomUserRole.Editor)
                    if (status == CustomPostStatus.Any)
                        postList = db.vw_Posts.ToList();
                    else
                        postList = db.vw_Posts.Where(p => p.Status == status).ToList();

                //CR 27/02/2022 Writers can request only any post based on the status
                if (role == CustomUserRole.Writer)
                    if (status == CustomPostStatus.Any)
                        postList = db.vw_Posts.Where(p => p.UserName == usernameReq).ToList();
                    else
                        postList = db.vw_Posts.Where(p => p.Status == status && p.UserName == usernameReq).ToList();
            }
            else
            {   //CR 27/02/2022 Non-Authenticated user can read only Approved Posts.
                if (role == "")
                {   
                    postList = db.vw_Posts.Where(p => p.Status == "A").ToList();
                }
            }
            return postList;
        }
    }
}
